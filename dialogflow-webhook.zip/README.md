# Webhook for Dialogflow in Cibeles Project

Work locally:

    npm install
    
Zip and upload the dialogflow-webhook.zip file to lambda:

    zip -r dialogflow-webhook.zip *
